# MUSERVER DOCUMENTATION

In this repository you will find the documentation on the part of the MuServer, you can also use all the scripts already created as a study base to create new ones!

New functions can be added, so this repository can be updated at other times